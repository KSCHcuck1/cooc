# screenshot-winx32

> Capture a screenshot of your Windows machine

* **Windows Only** - Optimized for Windows systems
* No dependencies required!
* Promise based API
* JPG, PNG, BMP output formats supported

## Install

```bash
npm install screenshot-winx32
```

## Usage

### Basic screenshot
```js
const screenshot = require('screenshot-winx32')

screenshot().then((img) => {
  // img: Buffer filled with jpg goodness
}).catch((err) => {
  // Handle errors
})
```

### Different formats
```js
const screenshot = require('screenshot-winx32')

screenshot({format: 'png'}).then((img) => {
  // img: Buffer filled with png goodness
}).catch((err) => {
  // Handle errors
})
```

### Multiple displays
```js
screenshot.listDisplays().then((displays) => {
  // displays: [{ id, name, width, height }, ...]
  screenshot({ screen: displays[0].id })
    .then((img) => {
      // img: Buffer of screenshot of the first display
    });
})
```

### Screenshot all displays
```js
screenshot.all().then((imgs) => {
  // imgs: an array of Buffers, one for each screen
})
```

### Save to file
```js
screenshot({ filename: 'shot.jpg' }).then((imgPath) => {
  // imgPath: absolute path to screenshot
});

// Absolute paths work too
screenshot({ filename: 'C:\\Users\\user\\Desktop\\demo.png' })
```

## screenshot() options

- `filename` Optional. Absolute or relative path to save output.
- `format` Optional. Valid values: `jpg`, `jpeg`, `png`, `bmp`
- `screen` Optional. Screen ID for multi-monitor setups

## License

MIT
