'strict mode'

// Module simplifié pour Windows uniquement
module.exports = require('./lib/win32')
